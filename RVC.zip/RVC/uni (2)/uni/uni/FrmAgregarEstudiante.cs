﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uni
{

    public partial class FrmAgregarEstudiante : Form
    {
        private Lista listaEstudiante; //atributo privado que hace referencia a la lista global
        public FrmAgregarEstudiante(Lista lista)
        {
            InitializeComponent();
            listaEstudiante = lista;
            txtDni.MaxLength = 8;
            txtDni.KeyPress += txtDni_KeyPress;
            txtPromedio.MaxLength = 5;
            txtPromedio.KeyPress += txtPromedio_KeyPress;
            txtNombre.KeyPress += txtNombre_KeyPress;
            txtApellido.KeyPress += txtApellido_KeyPress;

        }

        private void btnAgregarEstudiante_Click(object sender, EventArgs e)
        {
            string modalidad = cmbxModalidad.SelectedItem.ToString();
            string nombre = txtNombre.Text.Trim();
            string apellido = txtApellido.Text.Trim();
            string dni = txtDni.Text.Trim();
            string carrera = cmbxCarrera.SelectedItem.ToString();
            DateTime fechaNacimiento = dtpFechanacimiento.Value;

            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellido.Text) ||
                string.IsNullOrWhiteSpace(txtDni.Text) ||
                string.IsNullOrWhiteSpace(txtPromedio.Text) ||
                cmbxModalidad.SelectedItem == null ||
                cmbxCarrera.SelectedItem == null)
            {
                MessageBox.Show("Por favor complete todos los campos");
                return;

            }
            if (dni.Length != 8 || !dni.All(char.IsDigit))
            {
                MessageBox.Show("El DNI debe tener 8 dígitos.");
                txtDni.Clear();
                txtDni.Focus();
                return;
            }
            if (!double.TryParse(txtPromedio.Text.Trim(), out double Promedio))
            {
                MessageBox.Show("El promedio debe ser un número válido.");
                txtPromedio.Clear();
                txtPromedio.Focus();
                return;
            }
            if (Promedio < 0 || Promedio > 20)
            {
                MessageBox.Show("El promedio debe estar entre 0 y 20.");

                txtPromedio.Clear();
                txtPromedio.Focus();
                return;
            }
            if (cmbxModalidad.SelectedItem == null || cmbxCarrera.SelectedItem == null)
            {
                MessageBox.Show("Por favor seleccione una modalidad o Carrera.");
                cmbxModalidad.Focus();
                return;
            }
            Estudiante nuevoEstudiante = new Estudiante(nombre, apellido, dni, fechaNacimiento, modalidad, carrera, Promedio);
            listaEstudiante.AgregarEstudiante(nuevoEstudiante);

            LimpiarForm();


        }

        private void txtModalidad_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmAgregarEstudiante_Load(object sender, EventArgs e)
        {

        }
        private void txtDni_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite solo dígitos
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ignorar el carácter ingresado que no sea un número
            }
        }
        private void txtPromedio_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite solo dígitos y el punto decimal 
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true; // Ignora el carácter ingresado que no sea un número o punto decimal
            }

            // Permite solo un punto decimal
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true; // Ignora si ya hay un punto decimal en el texto
            }
        }
        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite solo letras y espacios
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; // Ignora el carácter ingresado que no sea una letra o espacio
            }
        }
        private void txtApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite solo letras y espacios
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; // Ignora el carácter ingresado que no sea una letra o espacio
            }
        }
        private void LimpiarForm()
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtDni.Clear();
            txtPromedio.Clear();
            cmbxModalidad.SelectedItem = null;
            cmbxCarrera.SelectedItem = null;
            dtpFechanacimiento.Value = DateTime.Now;
            txtNombre.Focus();
        }

        private void cmbxModalidad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
