﻿namespace uni
{
    partial class LoginFrm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnregistrate = new Button();
            btningresar = new Button();
            txtnombrelog = new TextBox();
            txtapellidolog = new TextBox();
            txtcontraseñalog = new TextBox();
            label4 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnregistrate
            // 
            btnregistrate.Location = new Point(130, 424);
            btnregistrate.Name = "btnregistrate";
            btnregistrate.Size = new Size(147, 32);
            btnregistrate.TabIndex = 0;
            btnregistrate.Text = "Registrate aquí";
            btnregistrate.UseVisualStyleBackColor = true;
            btnregistrate.Click += button1_Click;
            // 
            // btningresar
            // 
            btningresar.Location = new Point(146, 352);
            btningresar.Name = "btningresar";
            btningresar.Size = new Size(112, 35);
            btningresar.TabIndex = 1;
            btningresar.Text = "Ingresar";
            btningresar.UseVisualStyleBackColor = true;
            btningresar.Click += button2_Click;
            // 
            // txtnombrelog
            // 
            txtnombrelog.Location = new Point(61, 152);
            txtnombrelog.Name = "txtnombrelog";
            txtnombrelog.Size = new Size(303, 27);
            txtnombrelog.TabIndex = 4;
            // 
            // txtapellidolog
            // 
            txtapellidolog.Location = new Point(61, 221);
            txtapellidolog.Name = "txtapellidolog";
            txtapellidolog.Size = new Size(303, 27);
            txtapellidolog.TabIndex = 5;
            // 
            // txtcontraseñalog
            // 
            txtcontraseñalog.Location = new Point(61, 296);
            txtcontraseñalog.Name = "txtcontraseñalog";
            txtcontraseñalog.Size = new Size(303, 27);
            txtcontraseñalog.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(130, 401);
            label4.Name = "label4";
            label4.Size = new Size(162, 20);
            label4.TabIndex = 18;
            label4.Text = "¿No tienes una cuenta?";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources._0419331e_ae68_4262_b36a_98fc505ea920;
            pictureBox1.Location = new Point(158, 16);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(101, 104);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 19;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Stencil", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label1.Location = new Point(61, 131);
            label1.Name = "label1";
            label1.Size = new Size(69, 18);
            label1.TabIndex = 20;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Stencil", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label2.Location = new Point(61, 200);
            label2.Name = "label2";
            label2.Size = new Size(86, 18);
            label2.TabIndex = 21;
            label2.Text = "Apellidos";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Stencil", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label3.Location = new Point(61, 275);
            label3.Name = "label3";
            label3.Size = new Size(101, 18);
            label3.TabIndex = 22;
            label3.Text = "Contraseña";
            // 
            // LoginFrm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(425, 483);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(label4);
            Controls.Add(txtcontraseñalog);
            Controls.Add(txtapellidolog);
            Controls.Add(txtnombrelog);
            Controls.Add(btningresar);
            Controls.Add(btnregistrate);
            Name = "LoginFrm";
            Text = "Login";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnregistrate;
        private Button btningresar;
        private TextBox txtnombrelog;
        private TextBox txtapellidolog;
        private TextBox txtcontraseñalog;
        private Label label4;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}
