﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uni
{
    public partial class FrmMenú : Form
    {
        private Lista listaEstudiante;
        public FrmMenú(Lista lista)
        {
            InitializeComponent();
            listaEstudiante = lista;
        }
        private void BtnEstudiantes_Click(object sender, EventArgs e)
        {
            FrmEstudiantes frm = new FrmEstudiantes(listaEstudiante);
            frm.ShowDialog();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            FrmInscripciones frm = new FrmInscripciones();
            frm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            HistorialFrm frm = new HistorialFrm();
            frm.ShowDialog();
        }

        private void FrmMenú_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
