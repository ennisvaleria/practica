﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace uni
{
    internal class Nodo
    {
        public Usuario Usuario;
        public Estudiante Estudiante;
        public Nodo siguiente;
        public Nodo anterior;

        public Nodo(Usuario usuario)
        {
            Usuario = usuario;
            Estudiante = null;
            siguiente = null;
            anterior = null;
        }

        public Nodo(Estudiante estudiante)
        {
            Estudiante = estudiante;
            Usuario = null;
            siguiente = null;
            anterior = null;
        }

    }
}
