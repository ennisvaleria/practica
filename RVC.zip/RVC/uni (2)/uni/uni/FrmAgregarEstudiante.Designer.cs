﻿namespace uni
{
    partial class FrmAgregarEstudiante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAgregarEstudiante = new Button();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtPromedio = new TextBox();
            cmbxCarrera = new ComboBox();
            txtNombre = new TextBox();
            txtApellido = new TextBox();
            txtDni = new TextBox();
            label7 = new Label();
            cmbxModalidad = new ComboBox();
            dtpFechanacimiento = new DateTimePicker();
            SuspendLayout();
            // 
            // btnAgregarEstudiante
            // 
            btnAgregarEstudiante.Location = new Point(226, 374);
            btnAgregarEstudiante.Name = "btnAgregarEstudiante";
            btnAgregarEstudiante.Size = new Size(143, 38);
            btnAgregarEstudiante.TabIndex = 39;
            btnAgregarEstudiante.Text = "Agregar";
            btnAgregarEstudiante.UseVisualStyleBackColor = true;
            btnAgregarEstudiante.Click += btnAgregarEstudiante_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(295, 174);
            label6.Name = "label6";
            label6.Size = new Size(74, 20);
            label6.TabIndex = 38;
            label6.Text = "Promedio";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(295, 107);
            label5.Name = "label5";
            label5.Size = new Size(57, 20);
            label5.TabIndex = 37;
            label5.Text = "Carrera";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(295, 244);
            label4.Name = "label4";
            label4.Size = new Size(128, 20);
            label4.TabIndex = 36;
            label4.Text = "Fecha Nacimiento";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 244);
            label3.Name = "label3";
            label3.Size = new Size(66, 20);
            label3.TabIndex = 35;
            label3.Text = "Apellido";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(48, 177);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 34;
            label2.Text = "Nombre";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(48, 108);
            label1.Name = "label1";
            label1.Size = new Size(82, 20);
            label1.TabIndex = 33;
            label1.Text = "Modalidad";
            // 
            // txtPromedio
            // 
            txtPromedio.Location = new Point(295, 197);
            txtPromedio.Name = "txtPromedio";
            txtPromedio.Size = new Size(290, 27);
            txtPromedio.TabIndex = 32;
            // 
            // cmbxCarrera
            // 
            cmbxCarrera.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbxCarrera.FormattingEnabled = true;
            cmbxCarrera.Items.AddRange(new object[] { "Ing. Sistemas computacionales", "Ing. Química", "Ing. Civil", "Ing. Ambiental", "Medicina", "Administración de Empresas", "Gastronomía", "Ing. Mecatronica " });
            cmbxCarrera.Location = new Point(295, 130);
            cmbxCarrera.Name = "cmbxCarrera";
            cmbxCarrera.Size = new Size(290, 28);
            cmbxCarrera.TabIndex = 31;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(48, 200);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(208, 27);
            txtNombre.TabIndex = 29;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(48, 267);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(208, 27);
            txtApellido.TabIndex = 28;
            // 
            // txtDni
            // 
            txtDni.Location = new Point(48, 322);
            txtDni.Name = "txtDni";
            txtDni.Size = new Size(208, 27);
            txtDni.TabIndex = 42;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(48, 297);
            label7.Name = "label7";
            label7.Size = new Size(35, 20);
            label7.TabIndex = 43;
            label7.Text = "DNI";
            // 
            // cmbxModalidad
            // 
            cmbxModalidad.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbxModalidad.FormattingEnabled = true;
            cmbxModalidad.Items.AddRange(new object[] { "Presencial", "Virtual" });
            cmbxModalidad.Location = new Point(48, 130);
            cmbxModalidad.Name = "cmbxModalidad";
            cmbxModalidad.Size = new Size(208, 28);
            cmbxModalidad.TabIndex = 44;
            cmbxModalidad.SelectedIndexChanged += cmbxModalidad_SelectedIndexChanged;
            // 
            // dtpFechanacimiento
            // 
            dtpFechanacimiento.Location = new Point(296, 270);
            dtpFechanacimiento.Name = "dtpFechanacimiento";
            dtpFechanacimiento.Size = new Size(290, 27);
            dtpFechanacimiento.TabIndex = 46;
            // 
            // FrmAgregarEstudiante
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(613, 462);
            Controls.Add(dtpFechanacimiento);
            Controls.Add(cmbxModalidad);
            Controls.Add(label7);
            Controls.Add(txtDni);
            Controls.Add(btnAgregarEstudiante);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtPromedio);
            Controls.Add(cmbxCarrera);
            Controls.Add(txtNombre);
            Controls.Add(txtApellido);
            Name = "FrmAgregarEstudiante";
            Text = "FrmAgregarEstudiante";
            Load += FrmAgregarEstudiante_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn;
        private Button btnAgregarEstudiante;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtModalidad;
        private Label label7;
        public TextBox txtPromedio;
        public ComboBox cmbxCarrera;
        public TextBox txtNombre;
        public TextBox txtApellido;
        public TextBox txtDni;
        public ComboBox cmbxModalidad;
        public DateTimePicker dtpFechanacimiento;
    }
}