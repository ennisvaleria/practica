﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace uni
{
    public partial class RegistroFrm : Form
    {
        Lista listaUsuarios = new Lista();
        public RegistroFrm()
        {
            InitializeComponent();
            txtnombres.KeyPress += txtnombres_KeyPress;
            txtapellidos.KeyPress += txtapellidos_KeyPress;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombres = txtnombres.Text.Trim(); //Trim elimina espacios en blanco al inicio y al final
            string apellido = txtapellidos.Text.Trim();
            string contraseña = txtcontraseña.Text.Trim();
            if (nombres == "" || apellido == "" || contraseña == "") //o también puede ser: string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(apellido) || string.IsNullOrWhiteSpace(contraseña)
            {
                MessageBox.Show("Por favor complete todos los campos");
                return;
            }
            
            Usuario nuevo = new Usuario(nombres, apellido, contraseña);
            listaUsuarios.AgregarUsuario(nuevo);


            CrearArchivo(nombres, apellido, contraseña);


            txtnombres.Clear();
            txtapellidos.Clear();
            txtcontraseña.Clear();

        }
        private void CrearArchivo(string nombres, string apellidos, string contraseña)
        {

            string nombreArchivo = $"{nombres}_{apellidos}.txt";
            if (File.Exists(nombreArchivo))
            {
                txtnombres.Clear();
                txtapellidos.Clear();
                txtcontraseña.Clear();
                MessageBox.Show("Este usuario ya existe, porfavor ingrese distintos datos.");
                return;

            }
            using (StreamWriter sw = new StreamWriter(nombreArchivo))
            {
                    sw.WriteLine("Nombre: " + nombres);
                    sw.WriteLine("Apellido: " + apellidos);
                    sw.WriteLine("Contraseña: " + contraseña);
                MessageBox.Show("Usuario registrado correctamente");
            }
            
        }
        private void txtnombres_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Ignorar el carácter si no es una letra, control o espacio
            }
        }
        private void txtapellidos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Ignorar el carácter si no es una letra, control o espacio
            }
        }
    }
}
