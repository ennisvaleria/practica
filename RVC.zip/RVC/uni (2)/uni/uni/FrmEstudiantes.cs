﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uni
{
    public partial class FrmEstudiantes : Form
    {

        private Lista listaEstudiante;

        public FrmEstudiantes(Lista lista)
        {
            InitializeComponent();
            listaEstudiante = lista;

        }

        private void btnAgregarEstu_Click(object sender, EventArgs e)
        {
            FrmAgregarEstudiante frm = new FrmAgregarEstudiante(listaEstudiante);
            frm.ShowDialog();

            listaEstudiante.MostrarEstudianteEnDgv(dgvEstudiantes);


        }

        private void btnEditarEstu_Click(object sender, EventArgs e)
        {
            FrmEditar frm = new FrmEditar();
            frm.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FrmEstudiantes_Load(object sender, EventArgs e)
        {
            listaEstudiante.MostrarEstudianteEnDgv(dgvEstudiantes);
            dgvEstudiantes.ClearSelection();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
           listaEstudiante.EliminarEstudiante(dgvEstudiantes);
           listaEstudiante.MostrarEstudianteEnDgv(dgvEstudiantes);
           dgvEstudiantes.ClearSelection();

        }
    }
}
