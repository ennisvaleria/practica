﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace uni
{
    public class Usuario
    {
        public string btn_nombres;
        public string btn_apellidos;
        public string btn_contraseña;
        public Usuario(string nombres, string apellidos, string contraseña)
        {
            btn_nombres = nombres;
            btn_apellidos = apellidos;
            btn_contraseña = contraseña;
        }
    }
}
