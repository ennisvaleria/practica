﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uni
{
    public partial class HistorialFrm : Form
    {
        public HistorialFrm()
        {
            InitializeComponent();
        }

        private void HistorialFrm_Load(object sender, EventArgs e)
        {

        }
    }
}
