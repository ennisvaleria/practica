﻿namespace uni
{
    partial class FrmEstudiantes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEstudiantes));
            label1 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            comboBox1 = new ComboBox();
            button2 = new Button();
            dgvEstudiantes = new DataGridView();
            columNombres = new DataGridViewTextBoxColumn();
            ColumApellidos = new DataGridViewTextBoxColumn();
            ColumDni = new DataGridViewTextBoxColumn();
            ColumCarrera = new DataGridViewTextBoxColumn();
            columFecha = new DataGridViewTextBoxColumn();
            ColumModalidad = new DataGridViewTextBoxColumn();
            ColumPromedio = new DataGridViewTextBoxColumn();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            btnEliminar = new Button();
            btnEditarEstu = new Button();
            btnAgregarEstu = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvEstudiantes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Stencil", 20.25F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(14, 12);
            label1.MinimumSize = new Size(50, 29);
            label1.Name = "label1";
            label1.Size = new Size(388, 40);
            label1.TabIndex = 1;
            label1.Text = "LISTA DE ESTUDIANTES";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(14, 57);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(646, 27);
            textBox1.TabIndex = 2;
            // 
            // button1
            // 
            button1.Location = new Point(667, 57);
            button1.Name = "button1";
            button1.Size = new Size(86, 31);
            button1.TabIndex = 3;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.buscar;
            pictureBox1.Location = new Point(760, 60);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(23, 28);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 109);
            label2.Name = "label2";
            label2.Size = new Size(124, 20);
            label2.TabIndex = 12;
            label2.Text = "Filtrar por carrera";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(14, 132);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(317, 28);
            comboBox1.TabIndex = 13;
            // 
            // button2
            // 
            button2.Location = new Point(14, 168);
            button2.Name = "button2";
            button2.Size = new Size(133, 29);
            button2.TabIndex = 14;
            button2.Text = "Mostrar Todo";
            button2.UseVisualStyleBackColor = true;
            // 
            // dgvEstudiantes
            // 
            dgvEstudiantes.AllowUserToAddRows = false;
            dgvEstudiantes.AllowUserToDeleteRows = false;
            dgvEstudiantes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEstudiantes.Columns.AddRange(new DataGridViewColumn[] { columNombres, ColumApellidos, ColumDni, ColumCarrera, columFecha, ColumModalidad, ColumPromedio });
            dgvEstudiantes.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvEstudiantes.Location = new Point(14, 203);
            dgvEstudiantes.Name = "dgvEstudiantes";
            dgvEstudiantes.ReadOnly = true;
            dgvEstudiantes.RowHeadersWidth = 51;
            dgvEstudiantes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEstudiantes.Size = new Size(921, 412);
            dgvEstudiantes.TabIndex = 15;
            dgvEstudiantes.CellContentClick += dataGridView1_CellContentClick;
            // 
            // columNombres
            // 
            columNombres.HeaderText = "Nombres";
            columNombres.MinimumWidth = 6;
            columNombres.Name = "columNombres";
            columNombres.ReadOnly = true;
            columNombres.Width = 125;
            // 
            // ColumApellidos
            // 
            ColumApellidos.HeaderText = "Apellidos";
            ColumApellidos.MinimumWidth = 6;
            ColumApellidos.Name = "ColumApellidos";
            ColumApellidos.ReadOnly = true;
            ColumApellidos.Width = 125;
            // 
            // ColumDni
            // 
            ColumDni.HeaderText = "DNI";
            ColumDni.MinimumWidth = 6;
            ColumDni.Name = "ColumDni";
            ColumDni.ReadOnly = true;
            ColumDni.Width = 125;
            // 
            // ColumCarrera
            // 
            ColumCarrera.HeaderText = "Carrera";
            ColumCarrera.MinimumWidth = 6;
            ColumCarrera.Name = "ColumCarrera";
            ColumCarrera.ReadOnly = true;
            ColumCarrera.Width = 125;
            // 
            // columFecha
            // 
            columFecha.HeaderText = "Fecha de Nacimiento";
            columFecha.MinimumWidth = 6;
            columFecha.Name = "columFecha";
            columFecha.ReadOnly = true;
            columFecha.Width = 125;
            // 
            // ColumModalidad
            // 
            ColumModalidad.HeaderText = "Modalidad";
            ColumModalidad.MinimumWidth = 6;
            ColumModalidad.Name = "ColumModalidad";
            ColumModalidad.ReadOnly = true;
            ColumModalidad.Width = 125;
            // 
            // ColumPromedio
            // 
            ColumPromedio.HeaderText = "Promedio";
            ColumPromedio.MinimumWidth = 6;
            ColumPromedio.Name = "ColumPromedio";
            ColumPromedio.ReadOnly = true;
            ColumPromedio.Width = 125;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(976, 276);
            pictureBox4.Margin = new Padding(3, 4, 3, 4);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(31, 33);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 21;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.usuario;
            pictureBox3.Location = new Point(976, 374);
            pictureBox3.Margin = new Padding(3, 4, 3, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(31, 33);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 20;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(976, 464);
            pictureBox2.Margin = new Padding(3, 4, 3, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(22, 33);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(1012, 464);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(123, 33);
            btnEliminar.TabIndex = 18;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnEditarEstu
            // 
            btnEditarEstu.Location = new Point(1014, 374);
            btnEditarEstu.Name = "btnEditarEstu";
            btnEditarEstu.Size = new Size(123, 33);
            btnEditarEstu.TabIndex = 17;
            btnEditarEstu.Text = "Editar";
            btnEditarEstu.UseVisualStyleBackColor = true;
            btnEditarEstu.Click += btnEditarEstu_Click;
            // 
            // btnAgregarEstu
            // 
            btnAgregarEstu.Location = new Point(1012, 276);
            btnAgregarEstu.Name = "btnAgregarEstu";
            btnAgregarEstu.Size = new Size(123, 33);
            btnAgregarEstu.TabIndex = 16;
            btnAgregarEstu.Text = "Agregar";
            btnAgregarEstu.UseVisualStyleBackColor = true;
            btnAgregarEstu.Click += btnAgregarEstu_Click;
            // 
            // FrmEstudiantes
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1217, 683);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditarEstu);
            Controls.Add(btnAgregarEstu);
            Controls.Add(dgvEstudiantes);
            Controls.Add(button2);
            Controls.Add(comboBox1);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FrmEstudiantes";
            Text = "Lista";
            Load += FrmEstudiantes_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvEstudiantes).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private Button button1;
        private PictureBox pictureBox1;
        private Label label2;
        private ComboBox comboBox1;
        private Button button2;
        private DataGridView dgvEstudiantes;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Button btnEliminar;
        private Button btnEditarEstu;
        private Button btnAgregarEstu;
        private DataGridViewTextBoxColumn columNombres;
        private DataGridViewTextBoxColumn ColumApellidos;
        private DataGridViewTextBoxColumn ColumDni;
        private DataGridViewTextBoxColumn ColumCarrera;
        private DataGridViewTextBoxColumn columFecha;
        private DataGridViewTextBoxColumn ColumModalidad;
        private DataGridViewTextBoxColumn ColumPromedio;
    }
}