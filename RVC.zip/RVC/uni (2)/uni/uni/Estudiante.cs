﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uni
{
    public class Estudiante
    {
        public string Nombres;
        public string Apellidos;
        public string DNI;
        public DateTime Fecha;
        public string Modalidad;
        public string Carrera;
        public double Promedio;

        public Estudiante(string nombres, string apellidos, string dni, DateTime fecha, string modalidad, string carrera, double promedio)
        {
            Nombres = nombres;
            Apellidos = apellidos;
            DNI = dni;
            Fecha = fecha;
            Modalidad = modalidad;
            Carrera = carrera;
            Promedio = promedio;
        }
    }
}
