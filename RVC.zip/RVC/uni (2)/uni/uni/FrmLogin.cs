using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
namespace uni
{
    public partial class LoginFrm : Form

    {
        private Lista listaEstudiante = new Lista(); //
        public LoginFrm()
        {
            InitializeComponent();
            txtnombrelog.KeyPress += txtnombrelog_KeyPress; 
            txtapellidolog.KeyPress += txtnombrelog_KeyPress;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistroFrm frm = new RegistroFrm();
            frm.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void button2_Click(object sender, EventArgs e)
        {
           string nombre = txtnombrelog.Text.Trim();
           string apellido = txtapellidolog.Text.Trim();
           string contrase�a = txtcontrase�alog.Text.Trim();

           if (nombre == "" || apellido == "" || contrase�a == "")
           {
                MessageBox.Show("Por favor complete todos los campos");
                return;
           }

           string nombreArchivo = $"{nombre}_{apellido}.txt";
            if (!File.Exists(nombreArchivo))
            {
                
                MessageBox.Show("Usuario no encontrado, por favor registrese.");
                txtnombrelog.Clear();
                txtapellidolog.Clear();
                txtcontrase�alog.Clear();
                return;
            }

            string[] lineas = File.ReadAllLines(nombreArchivo);
            string contrase�aGuardada = lineas[2].Replace("Contrase�a: ", "").Trim();//es un arreglo que lee todas las lineas del archivo
                                                                                     //y busca la linea 2 que es donde esta la contrase�a, le quita el texto "Contrase�a: " y
                                                                                     //los espacios en blanco al inicio y al final y guarda el resultado en la variable contrase�aGuardada

            if (contrase�a == contrase�aGuardada)
            {
                FrmMen� frm = new FrmMen�(listaEstudiante);
                frm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Contrase�a incorrecta, intente nuevamente.");
                txtcontrase�alog.Clear();
            }
        }
        private void txtnombrelog_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void txtapellidolog_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
