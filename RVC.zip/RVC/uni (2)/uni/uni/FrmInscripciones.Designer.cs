﻿namespace uni
{
    partial class FrmInscripciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbEstudiantes = new ComboBox();
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            listBox1 = new ListBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // cmbEstudiantes
            // 
            cmbEstudiantes.FormattingEnabled = true;
            cmbEstudiantes.Location = new Point(137, 75);
            cmbEstudiantes.Name = "cmbEstudiantes";
            cmbEstudiantes.Size = new Size(169, 23);
            cmbEstudiantes.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(137, 48);
            label1.Name = "label1";
            label1.Size = new Size(169, 14);
            label1.TabIndex = 1;
            label1.Text = "Seleccione un estudiante";
            // 
            // button1
            // 
            button1.Location = new Point(137, 124);
            button1.Name = "button1";
            button1.Size = new Size(101, 23);
            button1.TabIndex = 2;
            button1.Text = "Agregar a cola";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(137, 165);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 3;
            button2.Text = "Atender";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(137, 205);
            button3.Name = "button3";
            button3.Size = new Size(122, 23);
            button3.TabIndex = 4;
            button3.Text = "Cancelar Inscripcion";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(137, 243);
            button4.Name = "button4";
            button4.Size = new Size(122, 23);
            button4.TabIndex = 5;
            button4.Text = "Conteo en cola";
            button4.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Items.AddRange(new object[] { "" });
            listBox1.Location = new Point(406, 89);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(295, 274);
            listBox1.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Narrow", 9.75F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label2.Location = new Point(406, 69);
            label2.Name = "label2";
            label2.Size = new Size(62, 16);
            label2.TabIndex = 8;
            label2.Text = " Pendientes";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(406, 381);
            label3.Name = "label3";
            label3.Size = new Size(205, 17);
            label3.TabIndex = 9;
            label3.Text = "Total de Inscripciones pendientes:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(663, 383);
            label4.Name = "label4";
            label4.Size = new Size(38, 15);
            label4.TabIndex = 10;
            label4.Text = "label4";
            label4.Click += label4_Click;
            // 
            // InscripcionesFrm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(listBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(cmbEstudiantes);
            Controls.Add(button2);
            Name = "InscripcionesFrm";
            Text = "InscripcionesFrm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbEstudiantes;
        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private ListBox listBox1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}