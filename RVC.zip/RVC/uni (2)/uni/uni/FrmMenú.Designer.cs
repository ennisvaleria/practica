﻿namespace uni
{
    partial class FrmMenú
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button4 = new Button();
            button3 = new Button();
            BtnEstudiantes = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(BtnEstudiantes);
            panel1.Location = new Point(86, 73);
            panel1.Name = "panel1";
            panel1.Size = new Size(202, 436);
            panel1.TabIndex = 1;
            panel1.Paint += panel1_Paint;
            // 
            // button4
            // 
            button4.Location = new Point(-3, 291);
            button4.Name = "button4";
            button4.Size = new Size(202, 43);
            button4.TabIndex = 3;
            button4.Text = "Historial";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Location = new Point(-1, 205);
            button3.Name = "button3";
            button3.Size = new Size(202, 43);
            button3.TabIndex = 2;
            button3.Text = "Inscripciones";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // BtnEstudiantes
            // 
            BtnEstudiantes.Location = new Point(3, 122);
            BtnEstudiantes.Name = "BtnEstudiantes";
            BtnEstudiantes.Size = new Size(202, 44);
            BtnEstudiantes.TabIndex = 0;
            BtnEstudiantes.Text = "Estudiantes";
            BtnEstudiantes.UseVisualStyleBackColor = true;
            BtnEstudiantes.Click += BtnEstudiantes_Click;
            // 
            // FrmMenú
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(407, 585);
            Controls.Add(panel1);
            Name = "FrmMenú";
            Text = "Menú";
            Load += FrmMenú_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Button BtnEstudiantes;
        private Button button4;
        private Button button3;
    }
}