﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace uni
{
    public class Lista
    {
        private Nodo cabeza;
        private Nodo cola;

        public Lista()
        {
            cabeza = null;
            cola = null;
        }

        public void AgregarUsuario(Usuario usuario)
        {
            
            Nodo nuevoNodo = new Nodo(usuario);
            if (cabeza == null)
            {
                cabeza = nuevoNodo;
                cola = nuevoNodo;
            }
            else
            {
                cola.siguiente = nuevoNodo;
                nuevoNodo.anterior = cola;
                cola = nuevoNodo;
            }
        }
        public void AgregarEstudiante(Estudiante estudiante)
        {
            Nodo actual = cabeza;
            while (actual != null)
            {
                if (actual.Estudiante.DNI == estudiante.DNI) //si el dni del estudiante que ya está en la lisa
                                                             //es igual al dni del estudiante que se quiere agregar
                {
                    MessageBox.Show("El estudiante con este DNI ya existe.");
                    return; //salgo del método sin agregar el estudiante
                }
                actual = actual.siguiente;
            }
            Nodo nuevoNodo = new Nodo(estudiante); //creo un nuevo nodo con el estudiante
            if (cabeza == null) 
            {
                cabeza = nuevoNodo;
                cola = nuevoNodo;
            }
            else
            {
                cola.siguiente = nuevoNodo;
                nuevoNodo.anterior = cola;
                cola = nuevoNodo;
            }
            MessageBox.Show("Estudiante agregado con éxito");
        }
        public void MostrarEstudianteEnDgv(DataGridView dgv)
        {
            dgv.DataSource = null;
            dgv.Rows.Clear();
            if (cabeza == null)
            {
                return;
            }
            Nodo actual = cabeza;
            
            while (actual != null)
            {
                if (actual.Estudiante != null)
                {
                    dgv.Rows.Add(
                    actual.Estudiante.Nombres,
                    actual.Estudiante.Apellidos,
                    actual.Estudiante.DNI,
                    actual.Estudiante.Carrera,
                    actual.Estudiante.Fecha.ToShortDateString(),
                    actual.Estudiante.Modalidad,
                    actual.Estudiante.Promedio);
                }

                actual = actual.siguiente;
              
            }
            dgv.ClearSelection();
        }
        public void EliminarEstudiante(DataGridView dgv)
        {
            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, seleccione una fila para eliminar.");
                return;
            }
            string dniSeleccionado = dgv.SelectedRows[0].Cells["ColumDni"].Value.ToString();

            if (cabeza == null)
            {
                return;
            }

            Nodo actual = cabeza;
            Nodo anterior = null;

            while (actual != null)
            {
                if (actual.Estudiante.DNI == dniSeleccionado)
                {
                    if (anterior == null)
                        cabeza = actual.siguiente;
                    else
                        anterior.siguiente = actual.siguiente;

                    MessageBox.Show("Estudiante eliminado correctamente.");
                    return;
                }
                anterior = actual;
                actual = actual.siguiente;
            }
        }

    }
}
