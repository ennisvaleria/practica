﻿namespace uni
{
    partial class RegistroFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtcontraseña = new TextBox();
            label3 = new Label();
            txtapellidos = new TextBox();
            txtnombres = new TextBox();
            label2 = new Label();
            btnregistro = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtcontraseña
            // 
            txtcontraseña.Location = new Point(63, 277);
            txtcontraseña.Name = "txtcontraseña";
            txtcontraseña.Size = new Size(303, 27);
            txtcontraseña.TabIndex = 15;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Stencil", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label3.Location = new Point(63, 256);
            label3.Name = "label3";
            label3.Size = new Size(101, 18);
            label3.TabIndex = 14;
            label3.Text = "Contraseña";
            // 
            // txtapellidos
            // 
            txtapellidos.Location = new Point(63, 213);
            txtapellidos.Name = "txtapellidos";
            txtapellidos.Size = new Size(303, 27);
            txtapellidos.TabIndex = 13;
            // 
            // txtnombres
            // 
            txtnombres.Location = new Point(63, 143);
            txtnombres.Name = "txtnombres";
            txtnombres.Size = new Size(303, 27);
            txtnombres.TabIndex = 12;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Stencil", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label2.Location = new Point(63, 192);
            label2.Name = "label2";
            label2.Size = new Size(86, 18);
            label2.TabIndex = 11;
            label2.Text = "Apellidos";
            // 
            // btnregistro
            // 
            btnregistro.BackColor = SystemColors.Window;
            btnregistro.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnregistro.Location = new Point(157, 339);
            btnregistro.Name = "btnregistro";
            btnregistro.Size = new Size(101, 39);
            btnregistro.TabIndex = 8;
            btnregistro.Text = "Registrar";
            btnregistro.UseVisualStyleBackColor = false;
            btnregistro.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources._0419331e_ae68_4262_b36a_98fc505ea920;
            pictureBox1.Location = new Point(157, 4);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(101, 104);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Stencil", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label1.Location = new Point(63, 121);
            label1.Name = "label1";
            label1.Size = new Size(77, 18);
            label1.TabIndex = 10;
            label1.Text = "Nombres";
            // 
            // RegistroFrm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(448, 451);
            Controls.Add(pictureBox1);
            Controls.Add(txtcontraseña);
            Controls.Add(label3);
            Controls.Add(txtapellidos);
            Controls.Add(txtnombres);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnregistro);
            Name = "RegistroFrm";
            Text = "Registro";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtcontraseña;
        private Label label3;
        private TextBox txtapellidos;
        private Label label2;
        private Button btnregistro;
        private PictureBox pictureBox1;
        private Label label1;
        public TextBox txtnombres;
    }
}